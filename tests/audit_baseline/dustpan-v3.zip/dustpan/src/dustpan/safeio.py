"""One guarded boundary for every file the scan opens.

Two v1 audit findings share a single cause: reads happened in three parsers,
each with its own idea of what was allowed.

AUD-V1-006 -- containment was checked once, on the top-level targets
discovery returned. PBIR reports are a tree of nested files (`page.json`,
`visual.json`, `mobile.json`, bookmarks, extensions) opened later by the
report parser, and none of those were re-checked, so a symlinked
`visual.json` pulled content from outside the requested root into the estate
and from there into an exported report.

AUD-V1-004 -- the CLI protected destinations by comparing them against
`Metric.source_path` and `Asset.source_path`. A structural `model.tmdl` that
defines no measure creates no Metric, and a nested PBIR file is not an
Asset's `source_path` (that is the report root), so neither was protected and
`--force` truncated both. The fix is to stop inferring what was read and
record it.

Every read goes through `authorise()`, which resolves the real path, enforces
containment, enforces the size budget, records the path in
`Estate.read_paths`, and records a material note on refusal.
"""

from __future__ import annotations

import os

from dustpan import limits
from dustpan.ir import Estate

__all__ = ["authorise", "was_read"]


def authorise(path: str, estate: Estate, stage: str) -> str | None:
    """Return the real path to open, or None if this read is refused.

    Refusals are always recorded, never silent: a file dustpan declined to
    read is missing evidence, and missing evidence must degrade the scan
    rather than quietly shrink it.
    """
    try:
        real = os.path.realpath(path)
    except OSError as exc:
        _note(estate, f"{stage}: {path}: could not resolve path: {exc}")
        return None

    root = getattr(estate, "scan_root", None)
    if root:
        real_root = os.path.realpath(root)
        prefix = real_root.rstrip(os.sep) + os.sep
        if not (real == real_root or real.startswith(prefix)):
            _note(
                estate,
                f"{stage}: refused '{path}' -- it resolves to '{real}', outside the "
                "scan root. dustpan does not read files from outside the tree it "
                "was pointed at, and the reference(s) it holds are not counted.",
            )
            return None

    try:
        size = os.path.getsize(real)
    except OSError as exc:
        _note(estate, f"{stage}: {path}: could not stat file: {exc}")
        return None

    if limits.exceeds(size, limits.MAX_FILE_BYTES):
        _note(
            estate,
            f"{stage}: {path}: "
            + limits.describe(
                size, limits.MAX_FILE_BYTES, "file", "DUSTPAN_MAX_FILE_BYTES"
            ),
        )
        return None

    if real not in estate.read_paths:
        estate.read_paths.append(real)
    return real


def was_read(estate: Estate) -> set[str]:
    """Every real path this scan opened. The CLI's do-not-overwrite list."""
    return set(estate.read_paths)


def _note(estate: Estate, message: str) -> None:
    if message not in estate.errors:
        estate.errors.append(message)
