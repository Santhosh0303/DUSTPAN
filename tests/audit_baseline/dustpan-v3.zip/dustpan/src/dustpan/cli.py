"""dustpan command line.

    dustpan scan PATH [--json F] [--markdown F] [--quiet]
                      [--min-confidence F] [--fail-on-findings] [--no-color]
    dustpan version

Exit codes
    0   scan completed, nothing to fail on
    1   high-severity findings present and --fail-on-findings was given
    2   bad usage, unusable path, or an output file could not be written

Public surface (see CONTRACT.md):
    main(argv: list[str] | None = None) -> int
"""

from __future__ import annotations

import argparse
import contextlib
import os
import sys
from collections.abc import Sequence

from dustpan import pipeline
from dustpan.ir import IR_VERSION, Estate

__all__ = ["build_parser", "main"]

EXIT_OK = 0
EXIT_FINDINGS = 1
EXIT_USAGE = 2

_EPILOG = """\
examples:
  dustpan scan ./MyProject                     read the report in the terminal
  dustpan scan ./MyProject --markdown out.md   write a report to paste in a ticket
  dustpan scan ./MyProject --json estate.json  full machine-readable dump
  dustpan scan . --quiet --fail-on-findings    CI gate: exit 1 on high-severity findings

Point PATH at the folder holding your .pbip file, or at any folder containing
*.SemanticModel / *.Dataset directories or a model.bim.

Confidence 1.00 means the normalised expressions are identical -- deterministic,
not a guess. Anything lower is a candidate for a human to read, never a delete
order. --min-confidence hides findings below a threshold.
"""


def _confidence(raw: str) -> float:
    try:
        value = float(raw)
    except (TypeError, ValueError):
        raise argparse.ArgumentTypeError(f"'{raw}' is not a number") from None
    if not 0.0 <= value <= 1.0:
        raise argparse.ArgumentTypeError(f"must be between 0.0 and 1.0 (got {value:g})")
    return value


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dustpan",
        description=(
            "Subtractive analysis for BI estates: finds duplicate, unused and "
            "drifting metric definitions."
        ),
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    scan = sub.add_parser(
        "scan",
        help="scan a folder of Power BI projects",
        description="Scan PATH and report duplicate, unused and unparsed measures.",
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    scan.add_argument("path", metavar="PATH", help="folder to scan")
    scan.add_argument(
        "--force",
        action="store_true",
        help="overwrite existing output files (never a scanned source)",
    )
    scan.add_argument(
        "--json",
        metavar="FILE",
        dest="json_path",
        help="write the full estate as JSON",
    )
    scan.add_argument(
        "--markdown",
        metavar="FILE",
        dest="markdown_path",
        help="write a ticket-ready markdown report",
    )
    scan.add_argument(
        "--quiet",
        action="store_true",
        help="print nothing to stdout (errors still go to stderr)",
    )
    scan.add_argument(
        "--min-confidence",
        metavar="FLOAT",
        type=_confidence,
        default=0.0,
        help="hide findings below this confidence (0.0-1.0, default 0.0)",
    )
    scan.add_argument(
        "--fail-on-findings",
        action="store_true",
        help="exit 1 if any high-severity finding survives filtering (for CI)",
    )
    scan.add_argument(
        "--no-color",
        action="store_true",
        help="never emit ANSI colour (NO_COLOR in the environment does the same)",
    )

    sub.add_parser("version", help="print the dustpan version and exit")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args_list = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()

    if not args_list:
        parser.print_help()
        return EXIT_USAGE

    try:
        args = parser.parse_args(args_list)
    except SystemExit as exc:  # --help (0) and argparse usage errors (2)
        return int(exc.code or 0)

    try:
        if args.command == "version":
            return _cmd_version()
        if args.command == "scan":
            return _cmd_scan(args)
    except KeyboardInterrupt:  # pragma: no cover - interactive only
        print("interrupted", file=sys.stderr)
        return 130

    parser.print_help()
    return EXIT_USAGE


def _cmd_version() -> int:
    print(f"dustpan {pipeline.version()} (IR v{IR_VERSION})")
    return EXIT_OK


def _cmd_scan(args: argparse.Namespace) -> int:
    root = os.path.abspath(os.path.expanduser(args.path))
    if not os.path.exists(root):
        print(f"dustpan: no such path: {args.path}", file=sys.stderr)
        return EXIT_USAGE
    if not os.path.isdir(root):
        print(
            f"dustpan: {args.path} is a file, not a folder.\n"
            "         Point dustpan at the folder that contains it.",
            file=sys.stderr,
        )
        return EXIT_USAGE

    estate = pipeline.scan(root)
    reported, hidden = pipeline.filter_by_confidence(estate, args.min_confidence)

    written, write_failed = _write_outputs(args, reported, root)

    if not args.quiet:
        from dustpan.output import console

        colour = False if args.no_color else None
        sys.stdout.write(console.render(reported, color=colour))
        if hidden:
            print(
                f"  ({hidden} finding(s) below --min-confidence "
                f"{args.min_confidence:g} hidden)\n"
            )
        for path in written:
            print(f"  wrote {path}")
        if written:
            print()

    if write_failed:
        return EXIT_USAGE

    high = sum(1 for f in reported.findings if f.severity == "high")
    if args.fail_on_findings and high:
        if not args.quiet:
            print(
                f"dustpan: {high} high-severity finding(s) -- failing as requested.",
                file=sys.stderr,
            )
        return EXIT_FINDINGS
    return EXIT_OK


def _requested(args: argparse.Namespace) -> list[tuple[str, str]]:
    """Requested (path, label) destinations, in a stable order."""
    return [
        (p, label)
        for p, label in ((args.json_path, "JSON"), (args.markdown_path, "markdown"))
        if p
    ]


def _scanned_sources(estate: Estate) -> set[str]:
    """Every file the scan actually opened, by resolved real path.

    These are never writable, with or without --force: overwriting one
    destroys the user's model. dustpan's whole promise is that it reads and
    reports, so a destination that aliases a source is a usage error, not an
    overwrite decision.

    AUD-V1-004: this used to be INFERRED from `Metric.source_path` and
    `Asset.source_path`, which misses every file that produces neither -- a
    structural `model.tmdl` defining no measure, and every nested PBIR file
    under a report root. Both were truncated by `--force`. The scan now
    records what it opened (`Estate.read_paths`) and this reads that; the
    source_path values are still unioned in as a belt-and-braces fallback for
    an Estate assembled without going through `scan()`.
    """
    paths: set[str] = set(getattr(estate, "read_paths", ()) or ())
    for item in list(estate.metrics) + list(estate.assets):
        source = getattr(item, "source_path", None)
        if source:
            with contextlib.suppress(OSError, ValueError):
                paths.add(os.path.realpath(source))
    return paths


def _write_outputs(
    args: argparse.Namespace, estate: Estate, root: str
) -> tuple[list[str], bool]:
    """Preflight, render, then atomically commit every requested output.

    Returns (paths actually written, failed). Nothing is written unless every
    destination passes preflight and every render succeeds, so a bad markdown
    render can never leave a stale JSON file claiming to match it.
    """
    requested = _requested(args)
    if not requested:
        return [], False

    from dustpan.output import writers

    sources = _scanned_sources(estate)
    seen: dict[str, str] = {}
    for path, label in requested:
        real = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
        if real in sources:
            print(
                f"dustpan: refusing to write {label} to {path}\n"
                "         -- that file was read by this scan. dustpan only ever\n"
                "         reads and reports; it will not overwrite your model.",
                file=sys.stderr,
            )
            return [], True
        if real in seen:
            print(
                f"dustpan: {label} and {seen[real]} both resolve to {path}\n"
                "         -- refusing to let one output silently replace the other.",
                file=sys.stderr,
            )
            return [], True
        if os.path.isdir(real):
            print(
                f"dustpan: {label} destination {path} is a directory, not a file.\n"
                "         Give a file path -- dustpan will not move or replace a "
                "directory.",
                file=sys.stderr,
            )
            return [], True
        if os.path.exists(real) and not args.force:
            print(
                f"dustpan: {path} already exists -- pass --force to overwrite.",
                file=sys.stderr,
            )
            return [], True
        seen[real] = label

    rendered: list[tuple[str, str, str]] = []
    for path, label in requested:
        renderer = writers.render_json if label == "JSON" else writers.render_markdown
        try:
            rendered.append((path, label, renderer(estate)))
        except Exception as exc:  # deliberate: never crash on a render bug
            print(f"dustpan: could not render {label}: {exc}", file=sys.stderr)
            return [], True

    # AUD-V1-005: all destinations commit together or none do. Writing them
    # one at a time could leave a fresh JSON beside a stale Markdown that
    # claims to describe the same scan.
    try:
        writers.commit_all([(path, text) for path, _label, text in rendered])
    except OSError as exc:
        print(
            f"dustpan: could not write outputs: {exc}\n"
            "         Nothing was written -- every destination is unchanged.",
            file=sys.stderr,
        )
        return [], True
    return [path for path, _label, _text in rendered], False


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
